package com.github.binarywang.demo.wx.mp.handler;

/**
 * @author Binary Wang
 */
public abstract class ScanHandler extends AbstractHandler {

}
